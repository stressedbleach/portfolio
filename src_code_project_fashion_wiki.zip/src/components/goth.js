import React from "react"; 
import goth1 from "./images/goth/goth1.jpeg";
import goth2 from "./images/goth/goth2.jpg";
import goth3 from "./images/goth/goth3.jpg";
import goth4 from "./images/goth/goth4.jpg";
import goth5 from "./images/goth/goth5.jpg";
import goth6 from "./images/goth/goth6.jpg";

const Goth = ()=>{ 
        return( 
               <div className="gothpage">
                <div> 
                        <h2 className="header">Romantic Goth</h2> 
                        <p className="description">Goth is a beautiful subculture as is, but I decided to dive deeper into a subgenre, romantic goth. Romantic goth focuses more on the soft, elegant side of goth culture. Such as pearls, dresses, suits. It still has its gothy edge, but it is sophisticated. Of course, with this alternative subculture, music counts too. Like said previously, most alternative styles focus on music and fashion together. Goth culture has been around even before the Victorian Era. It is always finding the beauty in the dark and twisted things.</p> 
                </div>
                <div className="image-container">
                        <img src={goth1} alt="goth" className="imgcard" />
                        <img src={goth2} alt="goth" className="imgcard" />
                        <img src={goth3} alt="goth" className="imgcard" />
                        <img src={goth4} alt="goth" className="imgcard" />
                        <img src={goth5} alt="goth" className="imgcard" />
                        <img src={goth6} alt="goth" className="imgcard" />

                    </div>
                </div>
        ) 
} 
export default Goth; 