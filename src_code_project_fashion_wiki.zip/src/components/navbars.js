import React from "react";
import { Outlet, Link } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <nav className="ui" style={{ height: "8em", margin: "2em" }}>
        <section className="ui-header, mainpage">
          <button className="ui button">
            <Link to="/home">Home</Link>
          </button>
          <button className="ui button">
            <Link to="/goth">Romantic Goth</Link>
          </button>
          <button className="ui button">
            <Link to="/kei">Visual Kei</Link>
          </button>
          <button className="ui button">
            <Link to="/punk">Indie Punk</Link>
          </button>
        </section>
      </nav>
      <Outlet />
    </>
  );
};

export default Navbar;
