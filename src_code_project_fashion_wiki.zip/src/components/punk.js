import React from "react";
import punk1 from "./images/punk/punk1.jpg";
import punk2 from "./images/punk/punk2.jpg";
import punk3 from "./images/punk/punk3.jpg";
import punk4 from "./images/punk/punk4.jpg";
import punk5 from "./images/punk/punk5.jpg";
import punk6 from "./images/punk/punk6.jpg";


const Punk = ()=>{ 
        return (
                <div className="punkpage">
                    <div>
                        <h2 className="header">Indie Punk</h2>
                        <p className="description"> Indie Punk, and Midwest emo go hand in hand with clothing styles, but indie punk is still very different than midwest emo. Indie punk is a subculture of punk, so there are similar ideals for indie punk. Such as defunding the government that does not help the people, believing in socialism and even fighting for equity and not equality. Indie punk has a lot of music about self-depricating jokes, poor life and usually about random stuff. Some artists are The front bottoms, McCafferty, and even Destroy Boys. </p>
                    </div>
                    <div className="image-container">
                        <img src={punk1} alt="indie punk" className="imgcard" />
                        <img src={punk2} alt="indie punk" className="imgcard" />
                        <img src={punk3} alt="indie punk" className="imgcard" />
                        <img src={punk4} alt="indie punk" className="imgcard" />
                        <img src={punk5} alt="indie punk" className="imgcard" />
                        <img src={punk6} alt="indie punk" className="imgcard" />

                    </div>
                </div>
            );
        };
        
export default Punk; 