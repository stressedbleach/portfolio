import React from "react";
import { Link } from "react-router-dom";
import ipunk from "./images/homeimgs/ipunk.jpg";
import rgoth from "./images/homeimgs/rgoth.jpg";
import vkei from "./images/homeimgs/vkei.jpg";

const Home = () => {
  return (
    <div className="homepage">
      <div className="home-description">
        <h2>Alternative Subcultures</h2>
        <p>
          There are many styles under Alternative. Alternative style is not
          just a fashion style, but also can be a lifestyle. It can be a
          movement. Such as punks. They fall under alternative styles, but it
          is a lifestyle too. As much as you have to dress to look like the
          style, you also have to listen to the music genre, and have some
          similar ideals to the reason the style was originated at all. Most of
          the time, alternative subcultures heavily rely on music. Most of them
          are rooted from music, and movements connected to said music.
          Alternative is anything that is not socially accepted. Anything that
          is deemed not normal. Click the links below to learn more about each subculture.
        </p>
        <div className="image-container">
          <Link to="/punk" className="subculture-link">
            <img src={ipunk} alt="Punk" className="imgcard" />
            <div className="subculture-text">Indie Punk</div>
          </Link>
          <Link to="/goth" className="subculture-link">
            <img src={rgoth} alt="Goth" className="gothcard" />
            <div className="subculture-text">Romantic Goth</div>
          </Link>
          <Link to="/kei" className="subculture-link">
            <img src={vkei} alt="Visual Kei" className="imgcard" />
            <div className="subculture-text">Visual Kei</div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
