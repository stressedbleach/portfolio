import React from "react";
import kei1 from "./images/kei/kei1.jpeg";
import kei2 from "./images/kei/kei2.png";
import kei3 from "./images/kei/kei3.jpg";
import kei4 from "./images/kei/kei4.jpg";
import kei5 from "./images/kei/kei5.jpg";
import kei7 from "./images/kei/kei7.jpeg";

const Kei = () => {
    return (
        <div className="keipage">
            <div className="text">
                <h2 className="header">Visual Kei</h2>
                <p className="description">Visual Kei originates from Japan. Female visual kei fans are known as "bangya", otherwise also called, "band girl". It was originally based on Glam Rock, Goth or Punk visuals. Now, it is its own style, very popular in mulitple regions. Usually visual kei is wearing very flamboyant styles and hair. There are also multiple sub-genres under visual kei, each having it's own personalized style. The style is very popular in Shibuya, Tokyo, Harajuku, all places in Japan.</p>
            </div>
            <div className="image-container">
                <img src={kei1} alt="Visual Kei" className="imgcard" />
                <img src={kei2} alt="Visual Kei" className="imgcard" />
                <img src={kei3} alt="Visual Kei" className="imgcard" />
                <img src={kei4} alt="Visual Kei" className="imgcard" />
                <img src={kei5} alt="Visual Kei" className="imgcard" />
                <img src={kei7} alt="Visual Kei" className="imgcard" />
            </div>
        </div>
    );
};

export default Kei;
