import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './components/home';
import Navbar from './components/navbars';
import Kei from './components/kei';
import Goth from './components/goth';
import Punk from "./components/punk" ;



function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <h1 className="main-header">Alternative Subcultures</h1>
        <h2 className='main-header'> By Simridhi Sharma</h2>
        <Navbar />
        <Routes>
          <Route index ="/home" element={<Home />}/>
          <Route path="/home" element={<Home />}/>
          <Route path="/kei" element={<Kei />} />
          <Route path="/goth" element={<Goth />} />
          <Route path="/punk" element={<Punk />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
